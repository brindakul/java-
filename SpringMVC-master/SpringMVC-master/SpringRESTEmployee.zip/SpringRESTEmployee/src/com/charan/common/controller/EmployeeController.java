package com.charan.common.controller;

import com.charan.common.model.Employee;
import com.google.gson.Gson;

import java.util.HashMap;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

//Usage
//http://localhost:8080/SpringRESTEmployee/payroll/3

@Controller
@RequestMapping("/payroll")
public class EmployeeController {

	//@RequestMapping(value="/{name}", method = RequestMethod.GET)
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)	
	public @ResponseBody String getMovie(@PathVariable int id) {

		//model.addAttribute("Name", id+no_of_days);
		

	/* 
	 * 1. Store all the ids in an hashmap object.
	 * 2. If the id matches then get the employee payroll details from the object.
	 * 3. Calculate the monthly salary.
	 * 4. Return the employee data as a JSON object to the client.	
	 * 
	 *  
	 *  Assignment : Extend this program to accept no_of_days worked and calculate the salary for the number of days worked.
	 *  
	 */

		HashMap<Integer, Employee> hm1 = new HashMap<Integer, Employee>();
		
		hm1.put(1, new Employee (1, "Charan",55000, 3500, 2000,200));
		hm1.put(2, new Employee (2, "Ravi",55000, 3500, 2000,200));
		hm1.put(3, new Employee (3, "Surya",65000, 3500, 2000,200));
		
		//Retrieve the object based on the given id.
		Employee emp=null;
		if(hm1.containsKey(id))
		{
			emp = hm1.get(id);	
			
		}
		 	
		emp.setGross_sal(emp.getBasic() + emp.getHra() + emp.getHra());
		emp.setFinal_deductions((int) (emp.getDeductions() + (emp.getGross_sal()*0.2)));
		emp.setTotal_sal(emp.getGross_sal() - emp.getFinal_deductions());
		
		
		
		return new Gson().toJson(emp);
		
	}
	
	@RequestMapping(value = "/display", method = RequestMethod.POST)
	public ResponseEntity<String> createEmployee(@RequestBody String name)
	{
	    System.out.println(name);
	    return new ResponseEntity(HttpStatus.CREATED);
	}
	
}

